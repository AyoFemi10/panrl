# config.py

BOT_TOKEN ="7617242921:AAE4wniP5EY7EqjoNMq_UF1hWkZt6bNz_Yk"
BOT_OWNER_ID = 2348164765100  # Replace with your Telegram ID
OPENAI_API_KEY = "your-openai-api-key"